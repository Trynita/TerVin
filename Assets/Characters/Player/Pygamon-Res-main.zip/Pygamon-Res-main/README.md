# Pygamon-Res

# Dungeon Tileset
Itch.io dungeon tileset
[https://stealthix.itch.io/dungeon-tileset-32x32-px](https://stealthix.itch.io/dungeon-tileset-32x32-px)

# PNJ assets
[/assets/pnjs](/assets/pnjs)
Source : [](https://e1.pngegg.com/pngimages/474/311/png-clipart-re-side-character-sprites-v1-assorted-character-sprites-illustration-thumbnail.png)
Artist : [DoubleLeggy](https://www.deviantart.com/doubleleggy/)

# Dialogs assets
[/assets/dialogs](/assets/dialogs)

